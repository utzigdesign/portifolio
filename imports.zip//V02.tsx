import svgPaths from "./svg-jejilbetb";
import imgDsc07153 from "figma:asset/f557494adcd21e92bbdfddc7e36af7e7ce2fabde.png";

function Sidebar() {
  return (
    <div className="absolute bg-black h-[171px] left-[302px] overflow-clip rounded-bl-[20px] rounded-tl-[20px] shadow-[0px_4px_4px_0px_rgba(0,0,0,0.25)] top-[2969px] w-[1213px]" data-name="sidebar">
      <div className="absolute flex flex-col font-['SF_Pro:Regular',_sans-serif] font-normal inset-[50.29%_77.33%_16.37%_2.72%] justify-center leading-[0] text-[55px] text-white tracking-[5.5px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[80px]">|cases</p>
      </div>
    </div>
  );
}

function Sidebar1() {
  return <div className="absolute bg-black h-[171px] left-0 rounded-bl-[20px] rounded-tl-[20px] shadow-[0px_4px_4px_0px_rgba(0,0,0,0.25)] top-0 w-[1213px]" data-name="sidebar" />;
}

function Frame21() {
  return (
    <div className="absolute h-[171px] left-[302px] top-[2001px] w-[1213px]">
      <Sidebar1 />
      <div className="absolute flex flex-col font-['SF_Pro:Regular',_sans-serif] font-normal inset-[50.29%_77.82%_16.37%_2.23%] justify-center leading-[0] text-[55px] text-white tracking-[5.5px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[80px]">|cases</p>
      </div>
    </div>
  );
}

function Frame3() {
  return (
    <a className="absolute bg-[#d73235] block cursor-pointer h-[21px] left-[151px] overflow-clip rounded-[20px] top-[487px] w-[182px]" href="https://www.instagram.com/reel/DMYk24ayaja/?utm_source=ig_web_copy_link&igsh=MzRlODBiNWFlZA==">
      <div className="absolute flex flex-col font-['SF_Pro:Regular',_sans-serif] font-normal h-[12px] justify-center leading-[0] left-[91px] text-[#ebebeb] text-[12px] text-center top-[11px] tracking-[1.2px] translate-x-[-50%] translate-y-[-50%] w-[144px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[20px]">{`Link do lançamento `}</p>
      </div>
    </a>
  );
}

function Sidebar2() {
  return (
    <div className="absolute h-[596px] left-[11px] rounded-[20px] top-0 w-[483px]" data-name="sidebar">
      <div className="h-[596px] overflow-clip relative rounded-[inherit] w-[483px]">
        <Frame3 />
      </div>
      <div aria-hidden="true" className="absolute border border-[#d73235] border-solid inset-0 pointer-events-none rounded-[20px] shadow-[0px_4px_4px_0px_rgba(0,0,0,0.25)]" />
    </div>
  );
}

function Frame17() {
  return (
    <div className="absolute h-[599px] left-[294px] top-[2231px] w-[486px]">
      <Sidebar2 />
      <div className="absolute flex flex-col font-['SF_Pro:Regular',_sans-serif] font-normal justify-center leading-[0] left-[45px] text-[14px] text-black text-justify top-[383px] tracking-[1.4px] translate-y-[-50%] w-[412px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <ul className="list-disc">
          <li className="mb-0 ms-[21px]">
            <span className="leading-[20px]">Padronização de critérios e redução de vieses na avaliação.</span>
          </li>
          <li className="mb-0 ms-[21px]">
            <span className="leading-[20px]">{`Aumento da velocidade de avaliação dos palestrantes participantes em 40%. `}</span>
          </li>
          <li className="ms-[21px]">
            <span className="leading-[20px]">Triagem mais ágil: relatórios gerados em minutos após cada apresentação. Aumento do NPS do produto em 15%.</span>
          </li>
        </ul>
      </div>
      <div className="absolute flex flex-col font-['SF_Pro:Bold',_sans-serif] font-bold inset-[45.08%_37.45%_49.75%_39.92%] justify-center leading-[0] text-[16px] text-black text-center tracking-[1.6px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[20px]">Impacto</p>
      </div>
      <div className="absolute flex flex-col font-['SF_Pro:Bold',_sans-serif] font-bold inset-[6.68%_14.11%_88.76%_18.93%] justify-center leading-[0] text-[15px] text-black text-center tracking-[1.5px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[20px]">AI de avaliação de performance de palestrantes</p>
      </div>
      <div className="absolute flex flex-col font-['SF_Pro:Regular',_sans-serif] font-normal h-[163px] justify-center leading-[0] left-[45px] text-[14px] text-black text-justify top-[166.5px] tracking-[1.4px] translate-y-[-50%] w-[415px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[20px]">{`Como Product Owner na PSA, co‑conduzi com a Vent o MVP de uma IA que avalia a performance de palestrantes a partir de áudio/vídeo, transcrição (ASR) e sinais de prosódia (ritmo, pausas, muletas). Fiz discovery, defini critérios de avaliação e escopo do MVP, priorizei o backlog e liderei o go‑live no piloto da competição The Best Speaker Brasil. `}</p>
      </div>
    </div>
  );
}

function Frame5() {
  return (
    <a className="absolute bg-[#d73235] block cursor-pointer h-[21px] left-[151px] overflow-clip rounded-[20px] top-[487px] w-[182px]" href="https://framework-frontend-pearl.vercel.app/">
      <div className="absolute flex flex-col font-['SF_Pro:Regular',_sans-serif] font-normal h-[12px] justify-center leading-[0] left-[91px] text-[#ebebeb] text-[12px] text-center top-[11px] tracking-[1.2px] translate-x-[-50%] translate-y-[-50%] w-[144px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[20px]">{`Link da plataforma `}</p>
      </div>
    </a>
  );
}

function Sidebar3() {
  return (
    <div className="absolute h-[596px] left-[11px] rounded-[20px] top-0 w-[483px]" data-name="sidebar">
      <div className="h-[596px] overflow-clip relative rounded-[inherit] w-[483px]">
        <Frame5 />
      </div>
      <div aria-hidden="true" className="absolute border border-[#d73235] border-solid inset-0 pointer-events-none rounded-[20px] shadow-[0px_4px_4px_0px_rgba(0,0,0,0.25)]" />
    </div>
  );
}

function Frame27() {
  return (
    <div className="absolute h-[599px] left-[calc(50%+173px)] top-[2234px] w-[486px]">
      <Sidebar3 />
      <div className="absolute flex flex-col font-['SF_Pro:Regular',_sans-serif] font-normal justify-center leading-[0] left-[45px] text-[14px] text-black text-justify top-[370px] tracking-[1.4px] translate-y-[-50%] w-[412px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <ul className="list-disc">
          <li className="mb-0 ms-[21px]">
            <span className="leading-[20px]">Competição Tecnopuc Garage: elaboração do pitch e apresentação que ficou entre os 10 finalista da edição de 2025.</span>
          </li>
          <li className="mb-0 ms-[21px]">
            <span className="leading-[20px]">Validação problema–solução com stakeholders via entrevistas.</span>
          </li>
          <li className="ms-[21px]">
            <span className="leading-[20px]">Desenvolvimento visual da plataforma UI design.</span>
          </li>
        </ul>
      </div>
      <div className="absolute flex flex-col font-['SF_Pro:Bold',_sans-serif] font-bold inset-[45.08%_37.45%_49.75%_39.92%] justify-center leading-[0] text-[16px] text-black text-center tracking-[1.6px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[20px]">Impacto</p>
      </div>
      <div className="absolute flex flex-col font-['SF_Pro:Bold',_sans-serif] font-bold inset-[6.68%_14.11%_88.76%_18.93%] justify-center leading-[0] text-[15px] text-black text-center tracking-[1.5px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[20px]">UX/UI e Fundador da plataforma FRAMEWORK</p>
      </div>
      <div className="absolute flex flex-col font-['SF_Pro:Regular',_sans-serif] font-normal justify-center leading-[0] left-[59px] text-[14px] text-black text-justify top-[164px] tracking-[1.4px] translate-y-[-50%] w-[398px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[20px] whitespace-pre-wrap">{`Atuando como Product Designer e fundador da plataforma liderei o processo inicial de  discovery e desenho do MVP da Framework, incluindo validação de ideia, definição de proposta de valor e protótipos navegáveis. Colaborei com fundadores e mentores do ecossistema para refinar modelo de negócio e priorizar o roadmap. `}</p>
      </div>
    </div>
  );
}

function Frame6() {
  return (
    <a className="absolute bg-[#d73235] block cursor-pointer h-[21px] left-[151px] overflow-clip rounded-[20px] top-[487px] w-[182px]" href="https://www.archdaily.com.br/br/1029179/apartamento-palmeira-ultra">
      <div className="absolute flex flex-col font-['SF_Pro:Regular',_sans-serif] font-normal h-[12px] justify-center leading-[0] left-[91px] text-[#ebebeb] text-[12px] text-center top-[11px] tracking-[1.2px] translate-x-[-50%] translate-y-[-50%] w-[144px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[20px]">{`Link da publicação `}</p>
      </div>
    </a>
  );
}

function Sidebar4() {
  return (
    <div className="absolute h-[596px] left-[11px] rounded-[20px] top-0 w-[483px]" data-name="sidebar">
      <div className="h-[596px] overflow-clip relative rounded-[inherit] w-[483px]">
        <Frame6 />
      </div>
      <div aria-hidden="true" className="absolute border border-[#d73235] border-solid inset-0 pointer-events-none rounded-[20px] shadow-[0px_4px_4px_0px_rgba(0,0,0,0.25)]" />
    </div>
  );
}

function Frame28() {
  return (
    <div className="absolute h-[599px] left-[305px] top-[3194px] w-[486px]">
      <Sidebar4 />
      <div className="absolute flex flex-col font-['SF_Pro:Regular',_sans-serif] font-normal justify-center leading-[0] left-[45px] text-[14px] text-black text-justify top-[422px] tracking-[1.4px] translate-y-[-50%] w-[412px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <ul className="list-disc">
          <li className="mb-0 ms-[21px]">
            <span className="leading-[20px]">{`Aplicação de conceitos Lean Construction `}</span>
          </li>
          <li className="mb-0 ms-[21px]">
            <span className="leading-[20px]">Obra entregue em tempo recorde. 3 meses.</span>
          </li>
          <li className="ms-[21px]">
            <span className="leading-[20px]">{`Reconhecimento em site internacional. `}</span>
          </li>
        </ul>
      </div>
      <div className="absolute flex flex-col font-['SF_Pro:Bold',_sans-serif] font-bold inset-[59.06%_37.45%_35.76%_39.92%] justify-center leading-[0] text-[16px] text-black text-center tracking-[1.6px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[20px]">Impacto</p>
      </div>
      <div className="absolute flex flex-col font-['SF_Pro:Bold',_sans-serif] font-bold inset-[6.68%_14.11%_88.76%_18.93%] justify-center leading-[0] text-[15px] text-black text-center tracking-[1.5px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[20px]">Execução apto Palmeira - Publicação na plataforma Archidaily</p>
      </div>
      <div className="absolute flex flex-col font-['SF_Pro:Regular',_sans-serif] font-normal h-[260px] justify-center leading-[0] left-[45px] text-[14px] text-black text-justify top-[220px] tracking-[1.4px] translate-y-[-50%] w-[415px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[20px]">{`Conduzi o processo de execucao de reforma de um apartamento em porto alegre, do renomado escritório de arquitetura Ultra. Nele houveram diversos disafios, entre eles o tempo e acesso ao local. Com os proprietários, morando no apto, um dos maiores desafios, foram aliar logistica aos cronogramas da obra. Através de um planejamento bem defindo e visivel a todos, clientes e arquitetos, foi utilizado o grafico de gantt e relatorios semaais de prestacao de servico x servico concluido. Tudo isso colaborou para que o projeto e a execucao fossem reconhecidos em umas das principais plataforma de arquitetura online. `}</p>
      </div>
    </div>
  );
}

function Frame7() {
  return (
    <a className="absolute bg-[#d73235] block h-[21px] left-[84px] overflow-clip rounded-[20px] top-[487px] w-[151px]" href="https://profissionaissa.com.br/the-best-weekend/?utm_source=google&utm_medium=cpc&utm_campaign=institucional_exata&utm_term=profissionais+sa&utm_content=wordpress">
      <div className="absolute flex flex-col font-['SF_Pro:Regular',_sans-serif] font-normal h-[12px] justify-center leading-[0] left-[76px] text-[#ebebeb] text-[12px] text-center top-[11px] tracking-[1.2px] translate-x-[-50%] translate-y-[-50%] w-[144px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[20px]">{`Link dos psa.talk `}</p>
      </div>
    </a>
  );
}

function Frame4() {
  return (
    <a className="absolute bg-[#d73235] block h-[21px] left-[249px] overflow-clip rounded-[20px] top-[487px] w-[151px]" href="https://thebestspeaker.com.br/">
      <div className="absolute flex flex-col font-['SF_Pro:Regular',_sans-serif] font-normal h-[12px] justify-center leading-[0] left-[76px] text-[#ebebeb] text-[12px] text-center top-[11px] tracking-[1.2px] translate-x-[-50%] translate-y-[-50%] w-[144px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[20px]">{`Link dos TBS `}</p>
      </div>
    </a>
  );
}

function Sidebar5() {
  return (
    <div className="absolute h-[596px] left-[11px] rounded-[20px] top-0 w-[483px]" data-name="sidebar">
      <div className="cursor-pointer h-[596px] overflow-clip relative rounded-[inherit] w-[483px]">
        <Frame7 />
        <Frame4 />
      </div>
      <div aria-hidden="true" className="absolute border border-[#d73235] border-solid inset-0 pointer-events-none rounded-[20px] shadow-[0px_4px_4px_0px_rgba(0,0,0,0.25)]" />
    </div>
  );
}

function Frame29() {
  return (
    <div className="absolute h-[599px] left-[calc(50%+184px)] top-[3197px] w-[486px]">
      <Sidebar5 />
      <div className="absolute flex flex-col font-['SF_Pro:Regular',_sans-serif] font-normal justify-center leading-[0] left-[45px] text-[14px] text-black text-justify top-[390px] tracking-[1.4px] translate-y-[-50%] w-[412px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <ul className="list-disc">
          <li className="mb-0 ms-[21px]">
            <span className="leading-[20px]">{`Criação de BPs dos produtos. `}</span>
          </li>
          <li className="mb-0 ms-[21px]">
            <span className="leading-[20px]">{`Meta de 40 alunos por imersão batida em todas as edições. Lucro de 25%. `}</span>
          </li>
          <li className="mb-0 ms-[21px]">
            <span className="leading-[20px]">{`Co-desenvolvimento UI design de website e LPs. `}</span>
          </li>
          <li className="mb-0 ms-[21px]">
            <span className="leading-[20px]">Definição estratégica dos produtos.</span>
          </li>
          <li className="ms-[21px]">
            <span className="leading-[20px]">Processo de discovery e criação da jornada do cliente.</span>
          </li>
        </ul>
      </div>
      <div className="absolute flex flex-col font-['SF_Pro:Bold',_sans-serif] font-bold inset-[47.21%_37.45%_47.61%_39.92%] justify-center leading-[0] text-[16px] text-black text-center tracking-[1.6px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[20px]">Impacto</p>
      </div>
      <div className="absolute flex flex-col font-['SF_Pro:Bold',_sans-serif] font-bold inset-[6.68%_14.11%_88.76%_18.93%] justify-center leading-[0] text-[15px] text-black text-center tracking-[1.5px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[20px]">Co-criação, gerenciamento e criação digital de produtos-serviço</p>
      </div>
      <div className="absolute flex flex-col font-['SF_Pro:Regular',_sans-serif] font-normal justify-center leading-[0] left-[59px] text-[14px] text-black text-justify top-[190px] tracking-[1.4px] translate-y-[-50%] w-[398px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[20px]">Produto presencial, onde fui o gestor e executor de 4 edições. Um produto online, onde fui o criador da versão alfa e host do produto. E o principal produto da empresa, um concurso onde co-geri todo o ecossistema de execução. Em todos eles, co-desenvolvi LPs comerciais, estratégias comerciais, estratégias financeiras, criação e desenvolvimento web. Produtos para palestrante - Psa.Talk</p>
      </div>
    </div>
  );
}

function Frame23() {
  return (
    <a className="absolute bg-black block cursor-pointer h-[36px] left-[calc(50%+95px)] overflow-clip rounded-[20px] shadow-[0px_4px_4px_0px_rgba(0,0,0,0.5)] top-[4439px] w-[193px]" href="https://drive.google.com/drive/folders/10UYLyGVBI6kLM3bKC0OXQlsrhXaB0HpJ?usp=drive_link">
      <div className="absolute flex flex-col font-['SF_Pro:Bold',_sans-serif] font-bold h-[12px] justify-center leading-[0] left-[97px] text-[#d73235] text-[20px] text-center top-[18px] tracking-[2px] translate-x-[-50%] translate-y-[-50%] w-[114px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[20px]">Baixar CV</p>
      </div>
    </a>
  );
}

function Frame26() {
  return (
    <a className="absolute bg-black block cursor-pointer h-[36px] left-[calc(50%+95px)] overflow-clip rounded-[20px] shadow-[0px_4px_4px_0px_rgba(0,0,0,0.5)] top-[4512px] w-[193px]" href="https://www.linkedin.com/in/jo%C3%A3o-vicente-utzig/">
      <div className="absolute flex flex-col font-['SF_Pro:Bold',_sans-serif] font-bold h-[12px] justify-center leading-[0] left-[97px] text-[#d73235] text-[20px] text-center top-[18px] tracking-[2px] translate-x-[-50%] translate-y-[-50%] w-[114px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[20px]">Linkedin</p>
      </div>
    </a>
  );
}

function Sidebar6() {
  return <div className="absolute bg-black h-[171px] left-0 rounded-bl-[20px] rounded-tl-[20px] shadow-[0px_4px_4px_0px_rgba(0,0,0,0.25)] top-0 w-[1213px]" data-name="sidebar" />;
}

function Frame22() {
  return (
    <div className="absolute h-[171px] left-[307px] top-[1037px] w-[1213px]">
      <Sidebar6 />
      <div className="absolute flex flex-col font-['SF_Pro:Regular',_sans-serif] font-normal inset-[40.94%_31.66%_12.87%_3.21%] justify-center leading-[0] text-[55px] text-white tracking-[5.5px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[80px]">|experiências profissionais</p>
      </div>
    </div>
  );
}

function Frame() {
  return (
    <div className="absolute bg-[#d73235] h-[22px] left-[80px] overflow-clip rounded-[20px] top-[292px] w-[158px]">
      <div className="absolute flex flex-col font-['SF_Pro:Regular',_sans-serif] font-normal h-[12px] justify-center leading-[0] left-[21px] text-[12px] text-justify text-white top-[11px] tracking-[1.2px] translate-y-[-50%] w-[116px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[20px]">{`Design Thinking `}</p>
      </div>
    </div>
  );
}

function Frame1() {
  return (
    <div className="absolute bg-[#d73235] h-[22px] left-[249px] overflow-clip rounded-[20px] top-[292px] w-[101px]">
      <div className="absolute flex flex-col font-['SF_Pro:Regular',_sans-serif] font-normal h-[12px] justify-center leading-[0] left-[31px] text-[12px] text-justify text-white top-[11px] tracking-[1.2px] translate-y-[-50%] w-[39px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[20px]">KPIs</p>
      </div>
    </div>
  );
}

function Frame2() {
  return (
    <div className="absolute bg-[#d73235] h-[22px] left-[361px] overflow-clip rounded-[20px] top-[292px] w-[123px]">
      <div className="absolute flex flex-col font-['SF_Pro:Regular',_sans-serif] font-normal h-[12px] justify-center leading-[0] left-[34px] text-[12px] text-justify text-white top-[11px] tracking-[1.2px] translate-y-[-50%] w-[76px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[20px]">Inovação</p>
      </div>
    </div>
  );
}

function Frame24() {
  return (
    <div className="absolute h-[314px] left-[302px] top-[1239px] w-[584px]">
      <div className="absolute bottom-[87.58%] flex flex-col font-['SF_Pro:Bold',_sans-serif] font-bold justify-center leading-[0] left-[17.64%] right-[19.35%] text-[15px] text-black text-center top-0 tracking-[1.5px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[20px]">
          {`| Product Owner - PSA | Profissionais SA `}
          <br aria-hidden="true" />
          2025
        </p>
      </div>
      <div className="absolute flex flex-col font-['SF_Pro:Regular',_sans-serif] font-normal h-[282px] justify-center leading-[0] left-0 text-[14px] text-black text-justify top-[166px] tracking-[1.4px] translate-y-[-50%] w-[584px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[20px]">Atuei como Product Owner na PSA, liderando o desenvolvimento de produtos digitais, experiências imersivas e soluções com IA voltadas à educação executiva e ao desenvolvimento de liderança. Coordenei a colaboração entre Comercial, Marketing, CRM, CS e Tecnologia para alinhar objetivos estratégicos e garantir consistência na entrega, além de supervisionar a implementação da primeira plataforma brasileira de avaliação de palestrantes com IA. Estruturei fluxos internos da área de produto e aumentei a eficiência da comunicação por meio de metodologias Ágeis e Scrum. Reportava-me diretamente ao C-level, traduzindo e co-criando a visão estratégica em iniciativas de produto acionáveis e resultados mensuráveis.</p>
      </div>
      <Frame />
      <Frame1 />
      <Frame2 />
    </div>
  );
}

function Frame8() {
  return (
    <div className="absolute bg-[#d73235] h-[22px] left-[54px] overflow-clip rounded-[20px] top-[287px] w-[158px]">
      <div className="absolute flex flex-col font-['SF_Pro:Regular',_sans-serif] font-normal h-[12px] justify-center leading-[0] left-[79px] text-[12px] text-center text-white top-[11px] tracking-[1.2px] translate-x-[-50%] translate-y-[-50%] w-[130px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[20px]">Produto Digital</p>
      </div>
    </div>
  );
}

function Frame9() {
  return (
    <div className="absolute bg-[#d73235] h-[22px] left-[223px] overflow-clip rounded-[20px] top-[287px] w-[101px]">
      <div className="absolute flex flex-col font-['SF_Pro:Regular',_sans-serif] font-normal h-[12px] justify-center leading-[0] left-[52.5px] text-[12px] text-center text-white top-[11px] tracking-[1.2px] translate-x-[-50%] translate-y-[-50%] w-[81px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[20px]">UX/UI</p>
      </div>
    </div>
  );
}

function Frame10() {
  return (
    <div className="absolute bg-[#d73235] h-[22px] left-[335px] overflow-clip rounded-[20px] top-[287px] w-[123px]">
      <div className="absolute flex flex-col font-['SF_Pro:Regular',_sans-serif] font-normal h-[12px] justify-center leading-[0] left-[61.5px] text-[12px] text-center text-white top-[11px] tracking-[1.2px] translate-x-[-50%] translate-y-[-50%] w-[117px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[20px]">Design System</p>
      </div>
    </div>
  );
}

function Frame25() {
  return (
    <div className="absolute h-[309px] left-[calc(50%+171px)] top-[1244px] w-[499px]">
      <div className="absolute flex flex-col font-['SF_Pro:Regular',_sans-serif] font-normal h-[200px] justify-center leading-[0] left-0 text-[14px] text-black text-justify top-[143px] tracking-[1.4px] translate-y-[-50%] w-[499px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[20px]">Como Product Designer e idealizador da Framework (startup em construção), do discovery ao delivery: conduzo pesquisa com arquitetos, escritórios e clientes, defino a proposta de valor e os princípios de UX, co-crio fluxos e o design system. A plataforma conecta arquitetos, clientes e escritórios, permitindo perfis profissionais, portfólios com descrições e informações técnicas, organização de projetos por tipologia. Nosso objetivo é dar visibilidade a bons projetos e acelerar colaborações de qualidade no ecossistema da arquitetura.</p>
      </div>
      <Frame8 />
      <Frame9 />
      <Frame10 />
      <div className="absolute bottom-[87.36%] flex flex-col font-['SF_Pro:Bold',_sans-serif] font-bold justify-center leading-[0] left-[12.63%] right-[15.67%] text-[15px] text-black text-center top-0 tracking-[1.5px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[20px]">
          | Product Designer - Startup Framework
          <br aria-hidden="true" />
          Now
        </p>
      </div>
    </div>
  );
}

function Frame11() {
  return (
    <div className="absolute bg-[#d73235] h-[22px] left-[382px] overflow-clip rounded-[20px] top-[1872px] w-[158px]">
      <div className="absolute flex flex-col font-['SF_Pro:Regular',_sans-serif] font-normal h-[12px] justify-center leading-[0] left-[79px] text-[12px] text-center text-white top-[11px] tracking-[1.2px] translate-x-[-50%] translate-y-[-50%] w-[130px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[20px]">Gantt</p>
      </div>
    </div>
  );
}

function Frame12() {
  return (
    <div className="absolute bg-[#d73235] h-[22px] left-[calc(25%+173px)] overflow-clip rounded-[20px] top-[1872px] w-[101px]">
      <div className="absolute flex flex-col font-['SF_Pro:Regular',_sans-serif] font-normal h-[12px] justify-center leading-[0] left-[32px] text-[12px] text-justify text-white top-[11px] tracking-[1.2px] translate-y-[-50%] w-[38px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[20px]">Lean</p>
      </div>
    </div>
  );
}

function Frame13() {
  return (
    <div className="absolute bg-[#d73235] h-[22px] left-[calc(25%+285px)] overflow-clip rounded-[20px] top-[1872px] w-[123px]">
      <div className="absolute flex flex-col font-['SF_Pro:Regular',_sans-serif] font-normal h-[12px] justify-center leading-[0] left-[65.5px] text-[12px] text-center text-white top-[11px] tracking-[1.2px] translate-x-[-50%] translate-y-[-50%] w-[81px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[20px]">Ágil</p>
      </div>
    </div>
  );
}

function Frame34() {
  return (
    <div className="absolute font-['SF_Pro:Bold',_sans-serif] font-bold h-[39.067px] leading-[0] left-[calc(25%+37px)] text-[15px] text-black text-center top-[1596px] tracking-[1.5px] w-[954.823px]">
      <div className="absolute bottom-0 flex flex-col justify-center left-0 right-[62.53%] top-0" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[20px]">| Construction Project Manager - MOC Engenharia - 2024</p>
      </div>
      <div className="absolute bottom-0 flex flex-col justify-center leading-[20px] left-[62.53%] right-0 top-0" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="mb-0">{`| Project Execution Manager - `}</p>
        <p>Arq. Carolina Dal Molin - 2022 -2023</p>
      </div>
    </div>
  );
}

function Frame14() {
  return (
    <div className="absolute bg-[#d73235] h-[22px] left-[calc(50%+225px)] overflow-clip rounded-[20px] top-[1872px] w-[158px]">
      <div className="absolute flex flex-col font-['SF_Pro:Regular',_sans-serif] font-normal h-[12px] justify-center leading-[0] left-[79px] text-[12px] text-center text-white top-[11px] tracking-[1.2px] translate-x-[-50%] translate-y-[-50%] w-[130px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[20px]">Planejamento</p>
      </div>
    </div>
  );
}

function Frame15() {
  return (
    <div className="absolute bg-[#d73235] h-[22px] left-[calc(75%+16px)] overflow-clip rounded-[20px] top-[1872px] w-[101px]">
      <div className="absolute flex flex-col font-['SF_Pro:Regular',_sans-serif] font-normal h-[12px] justify-center leading-[0] left-[52.5px] text-[12px] text-center text-white top-[11px] tracking-[1.2px] translate-x-[-50%] translate-y-[-50%] w-[81px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[20px]">Projestos</p>
      </div>
    </div>
  );
}

function Frame16() {
  return (
    <div className="absolute bg-[#d73235] h-[22px] left-[calc(75%+128px)] overflow-clip rounded-[20px] top-[1872px] w-[123px]">
      <div className="absolute flex flex-col font-['SF_Pro:Regular',_sans-serif] font-normal h-[12px] justify-center leading-[0] left-[14px] text-[12px] text-justify text-white top-[11px] tracking-[1.2px] translate-y-[-50%] w-[95px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[20px]">Steakholders</p>
      </div>
    </div>
  );
}

function Sidebar7() {
  return <div className="absolute bg-black h-[171px] left-0 rounded-br-[20px] rounded-tr-[20px] shadow-[0px_4px_4px_0px_rgba(0,0,0,0.25)] top-0 w-[1213px]" data-name="sidebar" />;
}

function Frame20() {
  return (
    <div className="absolute h-[171px] left-[57px] top-[3941px] w-[1213px]">
      <Sidebar7 />
      <div className="absolute flex flex-col font-['SF_Pro:Regular',_sans-serif] font-normal inset-[38.6%_2.39%_14.21%_35.86%] justify-center leading-[0] text-[#d73235] text-[55px] tracking-[5.5px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[80px]">{` |vamos trabalhar juntos?`}</p>
      </div>
    </div>
  );
}

function Sidebar8() {
  return <div className="absolute bg-[#d73235] h-[71px] left-0 rounded-[20px] shadow-[0px_4px_4px_0px_rgba(0,0,0,0.25)] top-0 w-[163px]" data-name="sidebar" />;
}

function Sidebar9() {
  return <div className="absolute bg-[#d99a02] h-[75px] left-[calc(50%-19px)] rounded-[20px] shadow-[0px_4px_4px_0px_rgba(0,0,0,0.25)] top-[calc(50%+40.5px)] translate-x-[-50%] translate-y-[-50%] w-[107px]" data-name="sidebar" />;
}

function Sidebar10() {
  return <div className="absolute bg-black h-[75px] left-[calc(50%-104px)] rounded-[20px] shadow-[0px_4px_4px_0px_rgba(0,0,0,0.25)] top-[calc(50%+40.5px)] translate-x-[-50%] translate-y-[-50%] w-[49px]" data-name="sidebar" />;
}

function Sidebar11() {
  return <div className="absolute bg-[#2e5fd5] h-[156px] left-[172px] rounded-[20px] shadow-[0px_4px_4px_0px_rgba(0,0,0,0.25)] top-0 w-[85px]" data-name="sidebar" />;
}

function Frame18() {
  return (
    <div className="absolute inset-[26.92%_6.52%_6.41%_73.55%]">
      <Sidebar8 />
      <Sidebar9 />
      <Sidebar10 />
      <Sidebar11 />
    </div>
  );
}

function Sidebar12() {
  return (
    <div className="absolute bg-black h-[276px] left-0 overflow-clip rounded-[20px] shadow-[0px_4px_4px_0px_rgba(0,0,0,0.25)] top-0 w-[1289px]" data-name="sidebar">
      <div className="absolute bottom-[25.64%] css-8rm0b2 flex flex-col font-['SF_Pro:Medium',_sans-serif] font-[510] justify-center leading-[0] left-[5.59%] right-[44.14%] text-[#ebebeb] text-[55px] text-justify top-1/2 tracking-[5.5px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[80px]">{` | joão vicente utzig `}</p>
      </div>
      <div className="absolute css-f0hnza flex flex-col font-['SF_Pro:Medium',_sans-serif] font-[510] inset-[17.95%_37.94%_57.69%_6.13%] justify-center leading-[0] text-[#ebebeb] text-[55px] tracking-[24.2px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[80px]">{`HEY! SOU O `}</p>
      </div>
      <Frame18 />
    </div>
  );
}

function Sidebar13() {
  return <div className="absolute bg-[#d73235] h-[71px] left-0 rounded-[20px] shadow-[0px_4px_4px_0px_rgba(0,0,0,0.25)] top-0 w-[163px]" data-name="sidebar" />;
}

function Sidebar14() {
  return <div className="absolute bg-[#d99a02] h-[75px] left-[calc(50%-19px)] rounded-[20px] shadow-[0px_4px_4px_0px_rgba(0,0,0,0.25)] top-[calc(50%+40.5px)] translate-x-[-50%] translate-y-[-50%] w-[107px]" data-name="sidebar" />;
}

function Sidebar15() {
  return <div className="absolute bg-black h-[75px] left-[calc(50%-104px)] rounded-[20px] shadow-[0px_4px_4px_0px_rgba(0,0,0,0.25)] top-[calc(50%+40.5px)] translate-x-[-50%] translate-y-[-50%] w-[49px]" data-name="sidebar" />;
}

function Sidebar16() {
  return <div className="absolute bg-[#2e5fd5] h-[156px] left-[172px] rounded-[20px] shadow-[0px_4px_4px_0px_rgba(0,0,0,0.25)] top-0 w-[85px]" data-name="sidebar" />;
}

function Frame19() {
  return (
    <div className="relative size-full">
      <Sidebar13 />
      <Sidebar14 />
      <Sidebar15 />
      <Sidebar16 />
    </div>
  );
}

function Frame30() {
  return (
    <div className="absolute h-[724px] left-[134px] top-[67px] w-[1289px]">
      <Sidebar12 />
      <div className="absolute flex inset-[43.09%_6.28%_35.36%_73.78%] items-center justify-center">
        <div className="flex-none h-[156px] rotate-[180deg] w-[257px]">
          <Frame19 />
        </div>
      </div>
      <div className="absolute flex flex-col font-['SF_Pro:Regular',_sans-serif] font-normal h-[290px] justify-center leading-[normal] left-[calc(50%-602.5px)] text-[24px] text-black text-justify top-[calc(50%+70px)] translate-y-[-50%] w-[823px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="mb-0">Desenho e gerencio produtos e experiências que conectam necessidades dos usuários às metas do negócio, guiado por uma mentalidade de design thinking e design system.</p>
        <p className="mb-0">&nbsp;</p>
        <p>Formado em Arquitetura e mestrando em Design Estratégico, aplico pensamento sistêmico, empatia e resolução criativa de problemas em cada projeto. Atuo no mapeamento de jornadas, na geração de insights, na facilitação de cocriação e na gestão de iniciativas estratégicas com times multidisciplinares.</p>
      </div>
      <div className="absolute h-[480px] left-[919px] top-[33px] w-[322.132px]" data-name="_DSC0715 2">
        <div className="absolute bottom-[-1.67%] left-[-1.24%] right-[-1.24%] top-0">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 331 488">
            <g filter="url(#filter0_d_1_171)" id="_DSC0715 2">
              <path d={svgPaths.pbd4fd80} shapeRendering="crispEdges" stroke="var(--stroke-0, #D73235)" />
            </g>
            <defs>
              <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="488" id="filter0_d_1_171" width="330.132" x="0" y="0">
                <feFlood floodOpacity="0" result="BackgroundImageFix" />
                <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
                <feOffset dy="4" />
                <feGaussianBlur stdDeviation="2" />
                <feComposite in2="hardAlpha" operator="out" />
                <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.25 0" />
                <feBlend in2="BackgroundImageFix" mode="normal" result="effect1_dropShadow_1_171" />
                <feBlend in="SourceGraphic" in2="effect1_dropShadow_1_171" mode="normal" result="shape" />
              </filter>
            </defs>
          </svg>
        </div>
      </div>
      <div className="absolute bottom-0 css-y8fthx flex flex-row gap-4 items-center justify-start leading-[0] left-[2.95%] text-[#d73235] text-[26px] top-[94.47%] font-['SF_Pro:Heavy',_sans-serif] font-[860] tracking-[3.5px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[41px] whitespace-nowrap">|PRODUCT MANAGER</p>
        <p className="leading-[41px] whitespace-nowrap">|PRODUCT DESIGNER</p>
        <p className="leading-[41px] whitespace-nowrap">|STRATEGIC DESIGNER</p>
      </div>
    </div>
  );
}

function Frame31() {
  return (
    <div className="absolute h-[838px] left-[176px] top-[1037px] w-[40px]">
      <div className="absolute flex items-center justify-center left-0 right-0 top-[42%]">
        <div className="flex-none h-[40px] rotate-[270deg] w-[600px]">
          <div className="css-gpejx1 flex flex-row gap-3 font-['SF_Pro:Heavy',_sans-serif] font-[860] items-center justify-center leading-[0] relative size-full text-[#d73235] text-[16px] tracking-[2px]" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[41px] whitespace-nowrap">|PRODUCT MANAGER</p>
            <p className="leading-[41px] whitespace-nowrap">|PRODUCT DESIGNER</p>
            <p className="leading-[41px] whitespace-nowrap">|STRATEGIC DESIGNER</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Frame32() {
  return (
    <div className="absolute h-[838px] left-[176px] top-[2001px] w-[40px]">
      <div className="absolute flex items-center justify-center left-0 right-0 top-[42%]">
        <div className="flex-none h-[40px] rotate-[270deg] w-[600px]">
          <div className="css-gpejx1 flex flex-row gap-3 font-['SF_Pro:Heavy',_sans-serif] font-[860] items-center justify-center leading-[0] relative size-full text-[#d73235] text-[16px] tracking-[2px]" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[41px] whitespace-nowrap">|PRODUCT MANAGER</p>
            <p className="leading-[41px] whitespace-nowrap">|PRODUCT DESIGNER</p>
            <p className="leading-[41px] whitespace-nowrap">|STRATEGIC DESIGNER</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Frame33() {
  return (
    <div className="absolute h-[838px] left-[176px] top-[2969px] w-[40px]">
      <div className="absolute flex items-center justify-center left-0 right-0 top-[42%]">
        <div className="flex-none h-[40px] rotate-[270deg] w-[600px]">
          <div className="css-gpejx1 flex flex-row gap-3 font-['SF_Pro:Heavy',_sans-serif] font-[860] items-center justify-center leading-[0] relative size-full text-[#d73235] text-[16px] tracking-[2px]" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[41px] whitespace-nowrap">|PRODUCT MANAGER</p>
            <p className="leading-[41px] whitespace-nowrap">|PRODUCT DESIGNER</p>
            <p className="leading-[41px] whitespace-nowrap">|STRATEGIC DESIGNER</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Sidebar17() {
  return <div className="absolute bg-black h-[4901px] left-0 shadow-[0px_4px_4px_0px_rgba(0,0,0,0.25)] top-[-2px] w-[58px]" data-name="sidebar" />;
}

function EpHouse() {
  return (
    <button className="absolute block cursor-pointer left-[10px] size-[30px] top-[39px]" data-name="ep:house">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 30 30">
        <g id="ep:house">
          <path d={svgPaths.p1691d680} fill="var(--fill-0, #D73235)" id="Vector" />
        </g>
      </svg>
    </button>
  );
}

function Group() {
  return (
    <div className="absolute inset-[12.5%]" data-name="Group">
      <div className="absolute inset-[-4.44%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 25 25">
          <g id="Group">
            <path d={svgPaths.p199de00} id="Vector" stroke="var(--stroke-0, #D73235)" strokeLinejoin="round" strokeWidth="2" />
            <g id="Vector_2"></g>
            <path d={svgPaths.p255e5000} id="Vector_3" stroke="var(--stroke-0, #D73235)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function IconParkOutlinePeopleMinus() {
  return (
    <button className="absolute block cursor-pointer left-[10px] overflow-clip size-[30px] top-[89px]" data-name="icon-park-outline:people-minus">
      <Group />
    </button>
  );
}

function IxAbout() {
  return (
    <button className="absolute block cursor-pointer left-[10px] size-[30px] top-[139px]" data-name="ix:about">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 30 30">
        <g id="ix:about">
          <path clipRule="evenodd" d={svgPaths.p3a673380} fill="var(--fill-0, #D73235)" fillRule="evenodd" id="Vector" />
        </g>
      </svg>
    </button>
  );
}

export default function V() {
  return (
    <div className="bg-white relative size-full" data-name="V02">
      <EpHouse />
      <IconParkOutlinePeopleMinus />
      <IxAbout />
      <Sidebar />
      <div className="absolute h-0 left-[134px] top-[986px] w-[1289.08px]">
        <div className="absolute bottom-[-0.5px] left-0 right-0 top-[-0.5px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1290 1">
            <path d="M0 0.5H1289.08" id="Vector 1" stroke="var(--stroke-0, black)" />
          </svg>
        </div>
      </div>
      <div className="absolute h-0 left-[134px] top-[1953px] w-[1289.08px]">
        <div className="absolute bottom-[-0.5px] left-0 right-0 top-[-0.5px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1290 1">
            <path d="M0 0.5H1289.08" id="Vector 1" stroke="var(--stroke-0, black)" />
          </svg>
        </div>
      </div>
      <div className="absolute h-0 left-[134px] top-[2915px] w-[1289.08px]">
        <div className="absolute bottom-[-0.5px] left-0 right-0 top-[-0.5px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1290 1">
            <path d="M0 0.5H1289.08" id="Vector 1" stroke="var(--stroke-0, black)" />
          </svg>
        </div>
      </div>
      <div className="absolute h-0 left-[134px] top-[3889px] w-[1289.08px]">
        <div className="absolute bottom-[-0.5px] left-0 right-0 top-[-0.5px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1290 1">
            <path d="M0 0.5H1289.08" id="Vector 1" stroke="var(--stroke-0, black)" />
          </svg>
        </div>
      </div>
      <div className="absolute h-0 left-[134px] top-[4860px] w-[1289.08px]">
        <div className="absolute bottom-[-0.5px] left-0 right-0 top-[-0.5px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1290 1">
            <path d="M0 0.5H1289.08" id="Vector 1" stroke="var(--stroke-0, black)" />
          </svg>
        </div>
      </div>
      <div className="absolute h-[7068.52px] left-[57.71px] top-[3.49px] w-0">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
          <g id="Vector 7"></g>
        </svg>
      </div>
      <Frame21 />
      <Frame17 />
      <Frame27 />
      <Frame28 />
      <Frame29 />
      <div className="absolute flex flex-col font-['SF_Pro:Regular',_sans-serif] font-normal h-[107px] justify-center leading-[20px] left-[calc(50%+95px)] text-[24px] text-black text-justify top-[4348.5px] tracking-[2.4px] translate-y-[-50%] w-[417px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="mb-0">joao.utzig98@outlook.com</p>
        <p>
          <br aria-hidden="true" />
          <br aria-hidden="true" />
          +55 51 9 98605258
        </p>
      </div>
      <Frame23 />
      <Frame26 />
      <Frame22 />
      <Frame24 />
      <Frame25 />
      <div className="absolute flex flex-col font-['SF_Pro:Regular',_sans-serif] font-normal h-[209px] justify-center leading-[0] left-[302px] text-[14px] text-black text-justify top-[1759.5px] tracking-[1.4px] translate-y-[-50%] w-[588px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[20px]">Na MOC Engenharia, gerenciei + de 20 projetos do planejamento à execução, revisando projetos e especificações para garantir conformidade com normas e objetivos. Modelei e acompanhei cronogramas, orçamentos e relatórios, mantendo stakeholders alinhados e propondo ajustes proativos para mitigar riscos. Mantive comunicação contínua com contratantes, arquitetos, engenheiros e clientes para assegurar prazos e qualidade. De forma transversal, apliquei metodologias ágeis e princípios de Lean Construction, como planejamento estruturado (ex.: Gantt) e ritos de alinhamento, para aumentar previsibilidade, reduzir desperdícios e promover melhoria contínua.</p>
      </div>
      <Frame11 />
      <Frame12 />
      <Frame13 />
      <Frame34 />
      <div className="absolute flex flex-col font-['SF_Pro:Regular',_sans-serif] font-normal h-[199px] justify-center leading-[0] left-[calc(50%+171px)] text-[14px] text-black text-justify top-[1749.5px] tracking-[1.4px] translate-y-[-50%] w-[503px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[20px]">Como Project Execution Manager e Arquiteto Assistente na Carolina Dalmolin Arquitetura, liderei a gestão de obras em projetos residenciais e comerciais de alto padrão, garantindo qualidade, controle de orçamento e fidelidade ao conceito. Além da coordenação em campo, estruturei a operação interna com fluxos inspirados em Agile e gestão por Gantt, melhorando a visibilidade de prazos, entregáveis e responsabilidades entre equipe de projeto e execução. Otimizei a comunicação com empreiteiros e fornecedores, criando rotinas de alinhamento e feedback contínuo para reduzir retrabalho e acelerar decisões.</p>
      </div>
      <Frame14 />
      <Frame15 />
      <Frame16 />
      <Frame20 />
      <Frame30 />
      <Frame31 />
      <Frame32 />
      <Frame33 />
      <Sidebar17 />
      <div className="absolute h-[543px] left-[215px] rounded-[30px] shadow-[0px_4px_50px_0px_rgba(0,0,0,0.5)] top-[4176px] w-[439px]" data-name="_DSC0715 3">
        <div className="absolute inset-0 overflow-hidden pointer-events-none rounded-[30px]">
          <img alt="" className="absolute h-[156.56%] left-0 max-w-none top-[-6.87%] w-[109.15%] grayscale" src={imgDsc07153} />
        </div>
      </div>
    </div>
  );
}